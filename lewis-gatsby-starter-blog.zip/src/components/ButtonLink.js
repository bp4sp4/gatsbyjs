import styled from "styled-components"

export const ButtonLink = styled.a`
  margin-right: 5vw;
`
