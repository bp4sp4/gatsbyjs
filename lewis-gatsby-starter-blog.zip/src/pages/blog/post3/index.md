---
title: "About me"
date: "2021-07-28"
---

![photo](post3photo1.jpg)

이름 : 박상훈 <br>
나이 : 24세  <br>
학력 : 대림대학교 컴퓨터정보학부 졸업예정 <br>
