---
title: "Skills"
date: "2021-07-28"
---



![photo](post2photo1.jpg)

<H1>I CAN DO<H1>

## #HTML #CSS #JS #JQUERY
