import ArrowBack from "./ArrowBack.svg"
import GatsbyIcon from "./GatsbyIcon.png"

export {ArrowBack, GatsbyIcon}
