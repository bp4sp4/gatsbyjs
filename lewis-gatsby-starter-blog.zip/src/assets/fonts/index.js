import IBMPlexMono400 from "./IBMPlexMono400.woff2"
import IBMPlexMono700 from "./IBMPlexMono700.woff2"

export {IBMPlexMono400, IBMPlexMono700}
