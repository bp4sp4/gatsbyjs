21/07/28

<h1>컴포넌트 만들기</h1><br>
<h3>AboutMe.js, Skills.js 만들었음</h3>

<p>컴포넌트 추가할때 꼭 해야하는것</p>

1. js파일을 만든다.
2. 만든후 export 만 해주는 index.js에서 예) export {AboutMe} from "./AboutMe"; 시켜준다.
3. index.js 에서  <AboutMe /> 컴포넌트를 생성해준다.<br>

## 추가해야할것들
<b>네이게이션바, 기타스타일작업(할거 많음), 오른쪽위 about에 뭐 넣을지 생각하기</b>